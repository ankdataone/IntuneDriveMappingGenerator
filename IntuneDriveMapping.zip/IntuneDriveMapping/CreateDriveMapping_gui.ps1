﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Microsoft Store APP Downloader'
$form.Size = New-Object System.Drawing.Size(550,200)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(10,100)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'next'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(85,100)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Exit'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please enter the Driveletter below:'
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,60)
$textBox.Size = New-Object System.Drawing.Size(20,20)
$form.Controls.Add($textBox)

$form.Topmost = $true

$form.Add_Shown({$textBox.Select()})
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $driveletter = $textBox.Text
    $driveletter
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Microsoft Store APP Downloader'
$form.Size = New-Object System.Drawing.Size(550,200)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(10,100)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'next'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(85,100)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Exit'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please enter the Label below:'
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,60)
$textBox.Size = New-Object System.Drawing.Size(500,20)
$form.Controls.Add($textBox)

$form.Topmost = $true

$form.Add_Shown({$textBox.Select()})
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $labelname = $textBox.Text
    $labelname
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Microsoft Store APP Downloader'
$form.Size = New-Object System.Drawing.Size(550,200)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(10,100)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'Generate'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(85,100)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Exit'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please enter the UNC-Path below:'
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,60)
$textBox.Size = New-Object System.Drawing.Size(500,20)
$form.Controls.Add($textBox)

$form.Topmost = $true

$form.Add_Shown({$textBox.Select()})
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $path1 = $textBox.Text
    $path1
}


$path1.Replace("\","\\")
$path = $path1.Replace("\","\\")
$path
New-Item -Name $driveletter -ItemType Directory -Path „.\out\“
(Get-Content -path .\template\DriveMapping.ps1 -Raw) -replace 'LW', $driveletter -replace 'Bezeichnung', $labelname -replace 'Pfad', $path | Set-Content -Path .\out\DriveMapping.ps1
(Get-Content -path .\template\delete_drivemapping.ps1 -Raw) -replace 'LW', $driveletter | Set-Content -Path .\out\delete_drivemapping.ps1
(Get-Content -path .\template\drivemappingdetection.ps1 -Raw) -replace 'LW', $driveletter | Set-Content -Path .\out\$driveletter\drivemappingdetection.ps1
$location = Get-Location
Start-Process -wait .\IntuneWinAppUtil\IntuneWinAppUtil.exe "-q -c $location\out -s DriveMapping.ps1 -o $location\out\$driveletter"