Intune Drive Mapping Tool

Start IntuneDriveMapping.cmd

Then enter the driveletter you wish to assign.
Click next
Enter the label for the mapped drive.
Click next
Enter the UNC-Path of the folder you wish to map.
click Generate


Check Out-Folder
You will find a folder with the name of your driveletter.
The folder contains the IntuneWin file and the 
detection script.