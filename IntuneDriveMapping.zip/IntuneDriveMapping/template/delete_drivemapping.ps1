<#
.DESCRIPTION
	This script deletes network drive mappings with PowerShell and the scheduled task.
	When executed under SYSTEM authority a scheduled task is created to ensure recurring script execution on each user logon.

.NOTES
	Author: Andreas Kutsch
#>

###########################################################################################
# Variable Declaration
###########################################################################################

$driveletter = "LW"

###########################################################################################
# Unmapping network drives
###########################################################################################

Remove-PSDrive $driveletter -Force -Verbose

###########################################################################################
# Unregister a scheduled task
###########################################################################################

$schtaskName = "IntuneDriveMapping_$driveletter"
Unregister-ScheduledTask -TaskName $schtaskName -Confirm:$false

###########################################################################################
# Done
###########################################################################################F






