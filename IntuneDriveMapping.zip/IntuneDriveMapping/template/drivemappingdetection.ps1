$driveletter = "LW"
if (Test-Path "$($env:programdata)\intune-drive-mapping-generator\DriveMappping_$driveletter.ps1") {
    Write-Host "Found it!"
}






